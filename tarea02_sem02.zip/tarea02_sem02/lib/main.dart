import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Notas - Formulario',
      home: const NotasFormScreen(),
    );
  }
}

class NotasFormScreen extends StatefulWidget {
  const NotasFormScreen({super.key});

  @override
  State<NotasFormScreen> createState() => _NotasFormScreenState();
}

class _NotasFormScreenState extends State<NotasFormScreen> {
  final _formKey = GlobalKey<FormState>();

  final _fechaCtrl = TextEditingController();
  final _seg1Ctrl = TextEditingController();
  final _ex1Ctrl  = TextEditingController();
  final _seg2Ctrl = TextEditingController();
  final _ex2Ctrl  = TextEditingController();

  String? _estudiante;

  final _companeros = const [
    'Mayerli Méndez',
    'Bruno Díaz',
    'Carla Pérez',
    'David Gómez',
    'Elena Ruiz',
  ];

  @override
  void dispose() {
    _fechaCtrl.dispose();
    _seg1Ctrl.dispose();
    _ex1Ctrl.dispose();
    _seg2Ctrl.dispose();
    _ex2Ctrl.dispose();
    super.dispose();
  }

  // ---- Validadores ----
  String? _validaFecha(String? v) {
    final value = (v ?? '').trim();
    if (value.isEmpty) return 'La fecha es obligatoria';
    final re = RegExp(r'^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/\d{4}$');
    if (!re.hasMatch(value)) return 'Usa el formato DD/MM/AAAA';

    final p = value.split('/');
    final d = int.parse(p[0]), m = int.parse(p[1]), y = int.parse(p[2]);
    try {
      final dt = DateTime(y, m, d);
      if (dt.year != y || dt.month != m || dt.day != d) {
        return 'Fecha inválida';
      }
    } catch (_) {
      return 'Fecha inválida';
    }
    return null;
  }

  String? _validaNota(String? v) {
    final s = (v ?? '').trim();
    if (s.isEmpty) return 'Obligatorio';
    final x = double.tryParse(s.replaceAll(',', '.'));
    if (x == null) return 'Solo números';
    if (x < 0 || x > 10) return 'Rango 0 a 10';
    return null;
  }

  // ---- Cálculos ----
  double _p(String t) => double.parse(t.replaceAll(',', '.'));

  Map<String, dynamic> _calcular() {
    final seg1 = _p(_seg1Ctrl.text);
    final ex1  = _p(_ex1Ctrl.text);
    final seg2 = _p(_seg2Ctrl.text);
    final ex2  = _p(_ex2Ctrl.text);

    final parcial1 = seg1 * 0.3 + ex1 * 0.2;
    final parcial2 = seg2 * 0.3 + ex2 * 0.2;
    final finalNota = parcial1 + parcial2;

    String estado;
    if (finalNota >= 7) {
      estado = 'APROBADO';
    } else if (finalNota >= 5) {
      estado = 'COMPLEMENTARIO';
    } else {
      estado = 'REPROBADO';
    }

    return {
      'parcial1': parcial1,
      'parcial2': parcial2,
      'final': finalNota,
      'estado': estado,
    };
  }

  void _mostrar() {
    if (!(_formKey.currentState?.validate() ?? false) || _estudiante == null) {
      if (_estudiante == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Selecciona un estudiante')),
        );
      }
      return;
    }

    final r = _calcular();
    final p1 = r['parcial1'] as double;
    final p2 = r['parcial2'] as double;
    final nf = r['final'] as double;
    final es = r['estado'] as String;

    final mensaje = StringBuffer()
      ..writeln('Nombre: $_estudiante')
      ..writeln('Fecha: ${_fechaCtrl.text}')
      ..writeln('Nota Parcial 1: ${p1.toStringAsFixed(2)}')
      ..writeln('Nota Parcial 2: ${p2.toStringAsFixed(2)}')
      ..writeln('Nota Final: ${nf.toStringAsFixed(2)}')
      ..write('Estado: $es');

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Resumen'),
        content: Text(mensaje.toString().replaceAll('\n', '\n')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cerrar'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Formateador para DD/MM/AAAA
    final fechaMask = _FechaMaskFormatter();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Registro de Notas'),
        centerTitle: true,
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            
            DropdownButtonFormField<String>(
              value: _estudiante,
              decoration: const InputDecoration(
                labelText: 'Estudiante',
                border: OutlineInputBorder(),
              ),
              items: _companeros
                  .map((n) => DropdownMenuItem(value: n, child: Text(n)))
                  .toList(),
              onChanged: (v) => setState(() => _estudiante = v),
              validator: (v) => v == null ? 'Seleccione un estudiante' : null,
            ),
            const SizedBox(height: 16),

            TextFormField(
              controller: _fechaCtrl,
              decoration: const InputDecoration(
                labelText: 'Fecha (DD/MM/AAAA)',
                hintText: 'Ej.: 28/10/2025',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.datetime,
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'[0-9/]')),
                fechaMask,
                LengthLimitingTextInputFormatter(10),
              ],
              validator: _validaFecha,
              autovalidateMode: AutovalidateMode.onUserInteraction,
            ),
            const SizedBox(height: 20),

            // Bloque Parcial 1
            const Text(
              'Parcial 1',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _seg1Ctrl,
                    decoration: const InputDecoration(
                      labelText: 'Parcial 1 (0–10)',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]')),
                    ],
                    validator: _validaNota,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _ex1Ctrl,
                    decoration: const InputDecoration(
                      labelText: 'Examen 1 (0–10)',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]')),
                    ],
                    validator: _validaNota,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Bloque Parcial 2
            const Text(
              'Parcial 2',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _seg2Ctrl,
                    decoration: const InputDecoration(
                      labelText: 'Parcial 2 (0–10)',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]')),
                    ],
                    validator: _validaNota,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _ex2Ctrl,
                    decoration: const InputDecoration(
                      labelText: 'Examen 2 (0–10)',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]')),
                    ],
                    validator: _validaNota,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            FilledButton.icon(
              onPressed: _mostrar,
              icon: const Icon(Icons.book),
              label: const Text('Mostrar'),
            ),
          ],
        ),
      ),
    );
  }
}


class _FechaMaskFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    var t = newValue.text.replaceAll(RegExp(r'[^0-9/]'), '');

    if (oldValue.text.length < newValue.text.length) {
      if (t.length == 2 && !t.endsWith('/')) t = '$t/';
      if (t.length == 5 && t[4] != '/') t = '${t.substring(0, 4)}/${t.substring(4)}';
    }
    if (t.length > 10) t = t.substring(0, 10);

    return TextEditingValue(
      text: t,
      selection: TextSelection.collapsed(offset: t.length),
    );
  }
}
