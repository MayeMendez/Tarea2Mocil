package com.example.tarea02_sem02

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
